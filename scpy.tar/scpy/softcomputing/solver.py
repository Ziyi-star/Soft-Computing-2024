""" Solver for different problems, i.e. to compare them against SC solutions. """
__author__    = "Christian Gruhl"
__copyright__ = "© 2024 Universität Kassel"
def rucksack_dp():
    pass